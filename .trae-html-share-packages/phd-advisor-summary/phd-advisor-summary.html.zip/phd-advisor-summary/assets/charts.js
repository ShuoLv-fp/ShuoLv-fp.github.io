(function() {
  var style = getComputedStyle(document.documentElement);
  var accent = style.getPropertyValue('--accent').trim();
  var accent2 = style.getPropertyValue('--accent2').trim();
  var ink = style.getPropertyValue('--ink').trim();
  var muted = style.getPropertyValue('--muted').trim();
  var rule = style.getPropertyValue('--rule').trim();
  var bg2 = style.getPropertyValue('--bg2').trim();

  var palette = [accent, accent2, muted, accent + '99', accent2 + '99'];

  // ---- Chart 1: region donut ----
  var regionData = [{"name": "亚洲", "value": 30}, {"name": "欧洲", "value": 28}, {"name": "加拿大 / 澳洲", "value": 24}];
  var c1 = echarts.init(document.getElementById('chart-region'), null, { renderer: 'svg' });
  c1.setOption({
    animation: false,
    color: [accent, accent2, muted],
    tooltip: { trigger: 'item', appendToBody: true, formatter: '{b}: {c} 位 ({d}%)' },
    series: [{
      type: 'pie',
      radius: ['45%', '72%'],
      center: ['50%', '50%'],
      itemStyle: { borderColor: bg2, borderWidth: 2 },
      label: { color: ink, formatter: '{b}\n{c} 位' },
      data: regionData
    }]
  });
  window.addEventListener('resize', function() { c1.resize(); });

  // ---- Chart 2: area bar ----
  var areaData = [{"name": "AI4Science / LLM", "value": 51}, {"name": "神经科学 / 脑动力学", "value": 17}, {"name": "复杂系统 / 网络", "value": 7}, {"name": "交叉方向", "value": 7}];
  var c2 = echarts.init(document.getElementById('chart-area'), null, { renderer: 'svg' });
  c2.setOption({
    animation: false,
    grid: { left: 40, right: 20, top: 20, bottom: 30 },
    tooltip: { trigger: 'axis', appendToBody: true, axisPointer: { type: 'shadow' } },
    xAxis: {
      type: 'value',
      minInterval: 1,
      axisLabel: { color: muted },
      splitLine: { lineStyle: { color: rule } }
    },
    yAxis: {
      type: 'category',
      data: areaData.map(function(d) { return d.name; }),
      axisLabel: { color: ink },
      axisLine: { lineStyle: { color: rule } }
    },
    series: [{
      type: 'bar',
      data: areaData.map(function(d) { return d.value; }),
      barWidth: '55%',
      itemStyle: { color: accent, borderRadius: [0, 4, 4, 0] },
      label: { show: true, position: 'right', color: ink, fontWeight: 700 }
    }]
  });
  window.addEventListener('resize', function() { c2.resize(); });

  // ---- Chart 3: top 15 horizontal bar ----
  var topData = [{"name": "Mrinmaya Sachan", "value": 40.6}, {"name": "Qi Liu", "value": 40.6}, {"name": "Martin McKeown", "value": 36.0}, {"name": "Juan Helen Zhou", "value": 35.2}, {"name": "Xiao Gaoxi", "value": 32.8}, {"name": "Alex Fornito", "value": 32.0}, {"name": "Hamid Karimi-Rouzbahani", "value": 32.0}, {"name": "Jason Mattingley", "value": 32.0}, {"name": "Jianfeng Feng", "value": 32.0}, {"name": "Karl Friston", "value": 32.0}, {"name": "Mark Woolrich", "value": 32.0}, {"name": "Rosalyn Moran", "value": 32.0}, {"name": "Sang-Hun Lee", "value": 32.0}, {"name": "Wei Lin", "value": 31.5}, {"name": "Sylvain Baillet", "value": 31.2}];
  var c3 = echarts.init(document.getElementById('chart-top'), null, { renderer: 'svg' });
  c3.setOption({
    animation: false,
    grid: { left: 150, right: 60, top: 10, bottom: 30 },
    tooltip: { trigger: 'axis', appendToBody: true, axisPointer: { type: 'shadow' } },
    xAxis: {
      type: 'value', max: 45,
      axisLabel: { color: muted },
      splitLine: { lineStyle: { color: rule } }
    },
    yAxis: {
      type: 'category',
      data: topData.map(function(d) { return d.name; }),
      axisLabel: { color: ink, fontSize: 11 },
      axisLine: { lineStyle: { color: rule } }
    },
    series: [{
      type: 'bar',
      data: topData.map(function(d) { return d.value; }),
      barWidth: '60%',
      itemStyle: { color: function(p) { return p.value >= 40 ? accent2 : accent; }, borderRadius: [0, 4, 4, 0] },
      label: { show: true, position: 'right', color: ink, fontWeight: 700, formatter: '{c}' }
    }]
  });
  window.addEventListener('resize', function() { c3.resize(); });
})();
